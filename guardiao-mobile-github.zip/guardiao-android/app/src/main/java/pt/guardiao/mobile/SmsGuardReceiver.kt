package pt.guardiao.mobile

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SmsMessage

/**
 * Recebe SMS e envia o conteúdo ao servidor Guardião para análise de scam.
 * Se o servidor responder "SCAM PROVÁVEL", é mostrada uma notificação de alerta.
 *
 * NOTA: o Android moderno só entrega SMS a apps com permissão RECEIVE_SMS;
 * o bloqueio *silencioso* de SMS exige ser a app de SMS predefinida (ver README).
 */
class SmsGuardReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val pdus = intent.extras?.get("pdus") as? Array<*> ?: return
        val sb = StringBuilder()
        var origin = ""
        for (p in pdus) {
            val msg = SmsMessage.createFromPdu(p as ByteArray)
            origin = msg.originatingAddress ?: ""
            sb.append(msg.messageBody)
        }
        val text = sb.toString()
        val prefs = context.getSharedPreferences("guardiao", Context.MODE_PRIVATE)
        val blocklist = prefs.getStringSet("blocklist", emptySet()) ?: emptySet()
        val digits = origin.filter { it.isDigit() }
        if (blocklist.any { b -> digits.endsWith(b.filter { it.isDigit() }.takeLast(9)) }) return

        Thread {
            val res = ServerSync.post(context, "/api/message",
                """{"number":"$origin","text":${jsonQuote(text)}}""")
            if (res?.contains("SCAM") == true) {
                ServerSync.localAlert(context, origin)
            }
        }.start()
    }

    private fun jsonQuote(s: String): String = "\"" + s.replace("\\", "\\\\")
        .replace("\"", "\\\"").replace("\n", "\\n") + "\""
}
