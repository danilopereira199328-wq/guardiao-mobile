package pt.guardiao.mobile

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telecom.TelecomManager

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val prefs = getSharedPreferences("guardiao", Context.MODE_PRIVATE)
        val serverUrl = findViewById<EditText>(R.id.serverUrl)
        val pin = findViewById<EditText>(R.id.pin)
        val status = findViewById<TextView>(R.id.status)
        val blocklistInfo = findViewById<TextView>(R.id.blocklistInfo)

        serverUrl.setText(prefs.getString("server_url", ""))
        pin.setText(prefs.getString("pin", ""))
        blocklistInfo.text = "Números bloqueados em cache: ${prefs.getInt("blocklist_size", 0)}"

        findViewById<Button>(R.id.saveAndSync).setOnClickListener {
            prefs.edit()
                .putString("server_url", serverUrl.text.toString().trim())
                .putString("pin", pin.text.toString().trim())
                .apply()
            Thread {
                val n = ServerSync.syncBlocklist(this)
                runOnUiThread {
                    status.text = if (n >= 0) "✅ Sincronizado ($n números bloqueados)"
                                  else "❌ Falha a ligar ao servidor"
                    blocklistInfo.text = "Números bloqueados em cache: $n"
                }
            }.start()
        }

        findViewById<Button>(R.id.requestRole).setOnClickListener { requestScreeningRole() }
    }

    private fun requestScreeningRole() {
        val status = findViewById<TextView>(R.id.status)
        val telecom = getSystemService(TelecomManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && telecom != null) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm?.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) == true &&
                !rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) {
                startActivityForResult(
                    rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 1)
            } else {
                status.text = "✅ Bloqueio de chamadas já ativo"
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1) {
            findViewById<TextView>(R.id.status).text =
                if (resultCode == RESULT_OK) "✅ Bloqueio de chamadas ativado!"
                else "⚠️ Permissão de bloqueio recusada"
        }
    }
}
