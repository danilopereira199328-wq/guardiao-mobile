package pt.guardiao.mobile

import android.content.Context
import android.telecom.Call
import android.telecom.CallScreeningService
import java.net.HttpURLConnection
import java.net.URL

/**
 * Bloqueia chamadas de números que constam na lista de bloqueio sincronizada
 * do servidor Guardião. O Android garante que a chamada nunca toca.
 */
class GuardiaoCallScreeningService : CallScreeningService() {

    override fun onScreenCall(call: Call) {
        val number = call.details.handle?.schemeSpecificPart ?: ""
        val prefs = getSharedPreferences("guardiao", Context.MODE_PRIVATE)
        val blocklist = prefs.getStringSet("blocklist", emptySet()) ?: emptySet()
        // compara ignorando formatação/prefixo
        val digits = number.filter { it.isDigit() }
        val localMatch = blocklist.any { b -> digits.endsWith(b.filter { it.isDigit() }.takeLast(9)) }
        // consulta em tempo real ao motor do PC (se o servidor estiver acessível);
        // sem rede, aplica apenas a lista sincronizada — nunca bloqueia por defeito
        val remoteMatch = try {
            ServerSync.check(this, number)?.optBoolean("block", false) ?: false
        } catch (_: Exception) { false }
        val matches = localMatch || remoteMatch

        val response = CallResponse.Builder()
            .setDisallowCall(matches)
            .setRejectCall(matches)
            .setSkipCallLog(!matches)
            .setSkipNotification(matches)
            .build()
        respondToCall(call, response)

        if (matches) {
            // regista o bloqueio no servidor (melhor esforço, em segundo plano)
            Thread {
                ServerSync.post(
                    this, "/api/block",
                    """{"number":"$number","reason":"Bloqueado no telemóvel (CallScreening)"}""")
            }.start()
        }
    }
}
