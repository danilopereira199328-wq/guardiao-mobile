package pt.guardiao.mobile

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONObject
import org.json.JSONArray

/** Comunicação com o servidor Guardião no PC (rede local). */
object ServerSync {

    fun post(context: Context, path: String, jsonBody: String): String? {
        val base = base(context) ?: return null
        return try {
            val conn = URL(base + path).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("Content-Type", "application/json")
            val pin = prefs(context).getString("pin", "") ?: ""
            if (pin.isNotEmpty()) conn.setRequestProperty("X-Guardiao-Pin", pin)
            conn.outputStream.use { it.write(jsonBody.toByteArray()) }
            BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
        } catch (e: Exception) {
            null
        }
    }

    /** Descarrega a lista de bloqueio do servidor para cache local. Devolve nº de itens (-1 = erro). */
    fun syncBlocklist(context: Context): Int {
        val base = base(context) ?: return -1
        return try {
            val conn = URL("$base/api/state").openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            val pin = prefs(context).getString("pin", "") ?: ""
            if (pin.isNotEmpty()) conn.setRequestProperty("X-Guardiao-Pin", pin)
            val json = JSONObject(BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() })
            val blocklist = json.getJSONArray("blocklist")
            val numbers = HashSet<String>()
            for (i in 0 until blocklist.length()) numbers.add(blocklist.getJSONObject(i).getString("number"))
            prefs(context).edit().putStringSet("blocklist", numbers)
                .putInt("blocklist_size", numbers.size).apply()
            numbers.size
        } catch (e: Exception) {
            -1
        }
    }

    /** Consulta em tempo real: o motor completo do PC diz se o número deve ser bloqueado. */
    fun check(context: Context, number: String): JSONObject? {
        val base = base(context) ?: return null
        return try {
            val conn = URL("$base/api/check?number=${URLEncoder.encode(number, "UTF-8")}").openConnection() as HttpURLConnection
            conn.connectTimeout = 4000
            conn.readTimeout = 4000
            val pin = prefs(context).getString("pin", "") ?: ""
            if (pin.isNotEmpty()) conn.setRequestProperty("X-Guardiao-Pin", pin)
            JSONObject(BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() })
        } catch (e: Exception) {
            null
        }
    }

    fun localAlert(context: Context, number: String) {
        val nm = context.getSystemService(NotificationManager::class.java)
        val id = "guardiao_alerts"
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(id, "Alertas Guardião", NotificationManager.IMPORTANCE_HIGH))
        }
        val n = Notification.Builder(context, id)
            .setContentTitle("⚠️ Guardião — scam detetado")
            .setContentText("Mensagem suspeita de $number foi registada no servidor.")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .build()
        nm.notify(number.hashCode(), n)
    }

    private fun prefs(context: Context) = context.getSharedPreferences("guardiao", Context.MODE_PRIVATE)
    private fun base(context: Context): String? =
        prefs(context).getString("server_url", null)?.trimEnd('/')
}
